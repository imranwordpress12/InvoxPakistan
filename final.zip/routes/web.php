<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Mail;
use App\Mail\CompanyWelcome;
use App\Mail\PaymentDue;
use App\Mail\PaymentReminder;
use App\Mail\PaymentThankYou;

Route::get('/test-email', function () {
    $company = \App\Models\Company::first();
    Mail::to('imranwordpress12@gmail.com')->send(new CompanyWelcome($company));
    return new \App\Mail\CompanyWelcome($company);
});

Route::get('/', function () {
    return view('welcome');
});

require __DIR__.'/admin.php';
require __DIR__.'/company.php';
