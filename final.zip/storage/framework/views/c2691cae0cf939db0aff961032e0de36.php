
<?php if(in_array($transaction->status, [\App\Models\Transaction::STATUS_PENDING, \App\Models\Transaction::STATUS_OVERDUE])): ?>
    <button
        type="button"
        class="btn btn-sm btn-success"
        data-bs-toggle="modal"
        data-bs-target="#mark-paid-<?php echo e($transaction->id); ?>"
    >
        Pay Now
    </button>

    <?php if (isset($component)) { $__componentOriginal2cfaf2d8c559a20e3495c081df2d0b10 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2cfaf2d8c559a20e3495c081df2d0b10 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.confirm-modal','data' => ['id' => 'mark-paid-'.$transaction->id,'title' => 'Pay Now — Invoice '.e($transaction->invoice_number).'','action' => route('admin.transactions.mark-paid', $transaction),'confirmLabel' => 'Confirm Payment','confirmClass' => 'btn-success','enctype' => 'multipart/form-data']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('confirm-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('mark-paid-'.$transaction->id),'title' => 'Pay Now — Invoice '.e($transaction->invoice_number).'','action' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('admin.transactions.mark-paid', $transaction)),'confirm-label' => 'Confirm Payment','confirm-class' => 'btn-success','enctype' => 'multipart/form-data']); ?>
        <dl class="row mb-3">
            <dt class="col-4">Company</dt>
            <dd class="col-8"><?php echo e($company->name); ?></dd>
            <dt class="col-4">Current Status</dt>
            <dd class="col-8"><?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['status' => $transaction->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($transaction->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?></dd>
        </dl>
        
        <div class="mb-3">
            <label class="form-label small mb-1">Payment Amount (PKR)</label>
            <input
                type="number"
                step="0.01"
                min="0"
                name="amount"
                value="<?php echo e(old('amount', $transaction->amount)); ?>"
                class="form-control"
                required
            >
        </div>

        <div class="mb-3">
            <label class="form-label small mb-1">Subscription Type</label>
            <select name="subscription_type" class="form-select">
                <option value="monthly" <?php if(old('subscription_type', $transaction->subscription_type) === 'monthly'): echo 'selected'; endif; ?>>Monthly</option>
                <option value="yearly" <?php if(old('subscription_type', $transaction->subscription_type) === 'yearly'): echo 'selected'; endif; ?>>Yearly</option>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label small mb-1">Billing Period Start Date</label>
            <input
                type="date"
                name="starts_at"
                value="<?php echo e(old('starts_at', $transaction->billing_period_start?->format('Y-m-d'))); ?>"
                class="form-control"
            >
        </div>

        <div class="mb-3">
            <label class="form-label small mb-1">Notes (optional)</label>
            <textarea name="notes" class="form-control" rows="2" placeholder="e.g. Paid via bank transfer"></textarea>
        </div>

        <div class="mb-3">
            <label for="payment-screenshot-<?php echo e($transaction->id); ?>" class="form-label small mb-1">Payment Screenshot (optional)</label>
            <input
                id="payment-screenshot-<?php echo e($transaction->id); ?>"
                type="file"
                name="payment_screenshot"
                class="form-control"
                accept="image/jpeg,image/png,image/webp"
            >
            <div class="form-text">JPG, PNG, or WebP up to 5 MB.</div>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2cfaf2d8c559a20e3495c081df2d0b10)): ?>
<?php $attributes = $__attributesOriginal2cfaf2d8c559a20e3495c081df2d0b10; ?>
<?php unset($__attributesOriginal2cfaf2d8c559a20e3495c081df2d0b10); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2cfaf2d8c559a20e3495c081df2d0b10)): ?>
<?php $component = $__componentOriginal2cfaf2d8c559a20e3495c081df2d0b10; ?>
<?php unset($__componentOriginal2cfaf2d8c559a20e3495c081df2d0b10); ?>
<?php endif; ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\InvoxPakistan\resources\views/admin/companies/_mark-paid-button.blade.php ENDPATH**/ ?>