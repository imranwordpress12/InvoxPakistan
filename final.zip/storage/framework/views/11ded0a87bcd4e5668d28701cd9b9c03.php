<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="h4 mb-3">Admin Dashboard</h1>

    <div class="row g-3 mb-4">
        <div class="col-md-4">
            <a href="<?php echo e(route('admin.companies.index')); ?>" class="text-decoration-none text-reset">
                <div class="card shadow-sm h-100">
                    <div class="card-body">
                        <div class="text-muted small">Total Companies</div>
                        <div class="h3 mb-0"><?php echo e($totalCompanies); ?></div>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-md-4">
            <a href="<?php echo e(route('admin.companies.index', ['subscription_status' => 'currently_active'])); ?>" class="text-decoration-none text-reset">
                <div class="card shadow-sm h-100 border-success">
                    <div class="card-body">
                        <div class="text-muted small">Paid Companies</div>
                        <div class="h3 mb-0 text-success"><?php echo e($paidCompanies); ?></div>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-md-4">
            <a href="<?php echo e(route('admin.companies.pending')); ?>" class="text-decoration-none text-reset">
                <div class="card shadow-sm h-100 border-warning">
                    <div class="card-body">
                        <div class="text-muted small">Pending Companies</div>
                        <div class="h3 mb-0 text-warning"><?php echo e($pendingCompanies); ?></div>
                    </div>
                </div>
            </a>
        </div>
    </div>

    <div class="row g-3 mb-4">
        <div class="col-md-6">
            <a href="<?php echo e(route('admin.dashboard')); ?>#recent-payments" class="text-decoration-none text-reset">
                <div class="card shadow-sm h-100 border-success">
                    <div class="card-body">
                        <div class="text-muted small">Paid Transactions</div>
                        <div class="h3 mb-0 text-success"><?php echo e($paidTransactions); ?></div>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-md-6">
            <a href="<?php echo e(route('admin.companies.pending')); ?>" class="text-decoration-none text-reset">
                <div class="card shadow-sm h-100 border-warning">
                    <div class="card-body">
                        <div class="text-muted small">Pending / Unpaid Transactions</div>
                        <div class="h3 mb-0 text-warning"><?php echo e($pendingTransactions); ?></div>
                    </div>
                </div>
            </a>
        </div>
    </div>

    <div class="card shadow-sm mb-4">
        <div class="card-header d-flex justify-content-between align-items-center">
            <span>Companies Overview</span>
            <a href="<?php echo e(route('admin.companies.index')); ?>" class="small">View all</a>
        </div>
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th>Company</th>
                        <th>Subscription</th>
                        <th>Status</th>
                        <th>Expiry</th>
                        <th class="text-end">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $companiesOverview; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($company->name); ?></td>
                            <td><?php echo e($company->latestSubscription ? ucfirst($company->latestSubscription->type) : '—'); ?></td>
                            <td><?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['status' => $company->latestSubscription?->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($company->latestSubscription?->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?></td>
                            <td><?php echo e($company->transactions->last()?->due_at?->format('d-M-Y') ?? '—'); ?></td>
                            <td class="text-end">
                                <a href="<?php echo e(route('admin.companies.show', $company)); ?>" class="btn btn-sm btn-outline-secondary">
                                    View
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="text-center text-muted py-4">No companies yet.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="card shadow-sm" id="recent-payments">
        <div class="card-header">Recent Payments</div>
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th>Company</th>
                        <th>Invoice Number</th>
                        <th>Subscription Type</th>
                        <th>Amount</th>
                        <th>Payment Date</th>
                        <th>Status</th>
                        <th class="text-end">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $recentPayments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($payment->company->name); ?></td>
                            <td><?php echo e($payment->invoice_number); ?></td>
                            <td><?php echo e(ucfirst($payment->subscription_type)); ?></td>
                            <td>PKR <?php echo e(number_format($payment->amount, 2)); ?></td>
                            <td><?php echo e($payment->paid_at->format('d-M-Y')); ?></td>
                            <td><?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['status' => $payment->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($payment->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?></td>
                            <td class="text-end">
                                <a href="<?php echo e(route('admin.companies.transactions', $payment->company)); ?>" class="btn btn-sm btn-outline-secondary">
                                    View
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center text-muted py-4">No payments yet.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\InvoxPakistan\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>