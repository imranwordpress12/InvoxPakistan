
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'id',
    'title',
    'action',
    'method' => 'POST',
    'confirmLabel' => 'Confirm',
    'confirmClass' => 'btn-primary',
    'enctype' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'id',
    'title',
    'action',
    'method' => 'POST',
    'confirmLabel' => 'Confirm',
    'confirmClass' => 'btn-primary',
    'enctype' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div class="modal fade" id="<?php echo e($id); ?>" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" action="<?php echo e($action); ?>" <?php if($enctype): ?> enctype="<?php echo e($enctype); ?>" <?php endif; ?>>
                <?php echo csrf_field(); ?>
                <?php if(strtoupper($method) !== 'POST'): ?>
                    <?php echo method_field($method); ?>
                <?php endif; ?>

                <div class="modal-header">
                    <h5 class="modal-title"><?php echo e($title); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <?php echo e($slot); ?>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn <?php echo e($confirmClass); ?>"><?php echo e($confirmLabel); ?></button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\InvoxPakistan\resources\views/components/confirm-modal.blade.php ENDPATH**/ ?>