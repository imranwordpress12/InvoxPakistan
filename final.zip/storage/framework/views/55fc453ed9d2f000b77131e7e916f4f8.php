
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['status']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['status']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $classes = match ($status) {
        'active', 'paid', 'successful' => 'text-bg-success',
        'due', 'draft' => 'text-bg-warning',
        'pending', 'expired', 'failed' => 'text-bg-danger',
        'cancelled', 'inactive' => 'text-bg-secondary',
        'submitted' => 'text-bg-info',
        default => 'text-bg-light border',
    };
?>

<span <?php echo e($attributes->merge(['class' => "badge $classes"])); ?>><?php echo e($status ? ucfirst($status) : '—'); ?></span>
<?php /**PATH C:\laragon\www\InvoxPakistan\resources\views/components/status-badge.blade.php ENDPATH**/ ?>