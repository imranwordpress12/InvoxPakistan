<?php $__env->startSection('title', 'Companies'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h1 class="h4 mb-0">Companies</h1>
        <div class="text-muted small">Total Companies: <?php echo e($totalCompanies); ?></div>
    </div>

    <div class="d-flex gap-2 mb-3">
        <a href="<?php echo e(route('admin.companies.create')); ?>" class="btn btn-primary">
            <i class="bi bi-plus-lg me-1"></i> Create Company
        </a>
        <a href="<?php echo e(route('admin.companies.pending')); ?>" class="btn btn-outline-secondary">
            <i class="bi bi-hourglass-split me-1"></i> Pending Companies
        </a>
    </div>

    <?php if(session('status')): ?>
        <div class="alert alert-success"><?php echo e(session('status')); ?></div>
    <?php endif; ?>

    <div class="card shadow-sm mb-3">
        <div class="card-body">
            <form method="GET" action="<?php echo e(route('admin.companies.index')); ?>" class="row g-2">
                <div class="col-md-4">
                    <input
                        type="text"
                        name="search"
                        value="<?php echo e(request('search')); ?>"
                        class="form-control"
                        placeholder="Search by name or email"
                    >
                </div>
                <div class="col-md-3">
                    <select name="subscription_type" class="form-select">
                        <option value="">All subscription types</option>
                        <option value="monthly" <?php if(request('subscription_type') === 'monthly'): echo 'selected'; endif; ?>>Monthly</option>
                        <option value="yearly" <?php if(request('subscription_type') === 'yearly'): echo 'selected'; endif; ?>>Yearly</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <select name="subscription_status" class="form-select">
                        <option value="">All subscription statuses</option>
                        <option value="active" <?php if(request('subscription_status') === 'active'): echo 'selected'; endif; ?>>Active</option>
                        <option value="pending" <?php if(request('subscription_status') === 'pending'): echo 'selected'; endif; ?>>Pending</option>
                        <option value="expired" <?php if(request('subscription_status') === 'expired'): echo 'selected'; endif; ?>>Expired</option>
                        <option value="cancelled" <?php if(request('subscription_status') === 'cancelled'): echo 'selected'; endif; ?>>Cancelled</option>
                    </select>
                </div>
                <div class="col-md-2 d-flex gap-2">
                    <button type="submit" class="btn btn-outline-primary flex-grow-1">Filter</button>
                    <?php if(request()->anyFilled(['search', 'subscription_type', 'subscription_status'])): ?>
                        <a href="<?php echo e(route('admin.companies.index')); ?>" class="btn btn-outline-secondary">
                            <i class="bi bi-x-lg"></i>
                        </a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>

    <div class="card shadow-sm">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead>
                    <tr>
                        <th>Company</th>
                        <th>Email</th>
                        <th>Subscription</th>
                        <th>Status</th>
                        <th>Start Date</th>
                        <th>End Date</th>
                        <th>Created At</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr
                            role="link"
                            style="cursor: pointer;"
                            onclick="window.location='<?php echo e(route('admin.companies.show', $company)); ?>';"
                        >
                            <td><?php echo e($company->name); ?></td>
                            <td><?php echo e($company->email); ?></td>
                            <td><?php echo e($company->latestSubscription ? ucfirst($company->latestSubscription->type) : '—'); ?></td>
                            <td><?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['status' => $company->latestSubscription?->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($company->latestSubscription?->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?></td>
                            <td><?php echo e($company->latestSubscription?->starts_at?->format('d-M-Y') ?? '—'); ?></td>
                            <td><?php echo e($company->latestSubscription?->ends_at?->format('d-M-Y') ?? '—'); ?></td>
                            <td><?php echo e($company->created_at->format('d-M-Y')); ?></td>
                            <td class="text-end" onclick="event.stopPropagation();">
                                <a href="<?php echo e(route('admin.companies.show', $company)); ?>" class="btn btn-sm btn-outline-secondary">View</a>
                                <a href="<?php echo e(route('admin.companies.edit', $company)); ?>" class="btn btn-sm btn-outline-secondary">Edit</a>
                                <button
                                    type="button"
                                    class="btn btn-sm btn-outline-danger"
                                    data-bs-toggle="modal"
                                    data-bs-target="#delete-company-<?php echo e($company->id); ?>"
                                >
                                    Delete
                                </button>

                                <?php if (isset($component)) { $__componentOriginal2cfaf2d8c559a20e3495c081df2d0b10 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2cfaf2d8c559a20e3495c081df2d0b10 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.confirm-modal','data' => ['id' => 'delete-company-'.$company->id,'title' => 'Delete company?','action' => route('admin.companies.destroy', $company),'method' => 'DELETE','confirmLabel' => 'Delete','confirmClass' => 'btn-danger']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('confirm-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('delete-company-'.$company->id),'title' => 'Delete company?','action' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('admin.companies.destroy', $company)),'method' => 'DELETE','confirm-label' => 'Delete','confirm-class' => 'btn-danger']); ?>
                                    Are you sure you want to delete <strong><?php echo e($company->name); ?></strong>? Its
                                    subscription and transaction history are kept, but it will disappear from this
                                    listing.
                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2cfaf2d8c559a20e3495c081df2d0b10)): ?>
<?php $attributes = $__attributesOriginal2cfaf2d8c559a20e3495c081df2d0b10; ?>
<?php unset($__attributesOriginal2cfaf2d8c559a20e3495c081df2d0b10); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2cfaf2d8c559a20e3495c081df2d0b10)): ?>
<?php $component = $__componentOriginal2cfaf2d8c559a20e3495c081df2d0b10; ?>
<?php unset($__componentOriginal2cfaf2d8c559a20e3495c081df2d0b10); ?>
<?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="text-center text-muted py-4">
                                No companies match these filters.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="mt-3">
        <?php echo e($companies->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\InvoxPakistan\resources\views/admin/companies/index.blade.php ENDPATH**/ ?>