<!DOCTYPE html>
<html lang="en">
<body>
    <p>Dear <?php echo e($transaction->company->name); ?>,</p>

    <p>
        Your subscription payment of <strong>PKR <?php echo e(number_format((float) $transaction->amount, 2)); ?></strong>
        for invoice <strong><?php echo e($transaction->invoice_number); ?></strong> is now <strong>DUE</strong>.
    </p>

    <p>
        <strong>Invoice:</strong> <?php echo e($transaction->invoice_number); ?><br>
        <strong>Plan:</strong> <?php echo e(ucfirst($transaction->subscription_type)); ?><br>
        <strong>Amount Due:</strong> PKR <?php echo e(number_format((float) $transaction->amount, 2)); ?><br>
        <strong>Due Date:</strong> <?php echo e($transaction->due_at ? $transaction->due_at->format('d-M-Y') : 'Today'); ?>

    </p>

    <p>Please complete your payment to ensure uninterrupted service.</p>

    <p>Best regards,<br><strong><?php echo e(config('app.name')); ?> Team</strong></p>
</body>
</html>
<?php /**PATH C:\laragon\www\InvoxPakistan\resources\views/emails/payment-due.blade.php ENDPATH**/ ?>