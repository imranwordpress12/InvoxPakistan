<?php $__env->startSection('title', 'Audit Logs'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="h4 mb-3">Audit Logs</h1>

    <div class="card shadow-sm">
        <div class="table-responsive">
            <table class="table table-sm align-middle mb-0">
                <thead>
                    <tr>
                        <th>When</th>
                        <th>Who</th>
                        <th>Action</th>
                        <th>Module</th>
                        <th>Company</th>
                        <th>IP Address</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php ($hasDetails = $log->description || $log->old_values || $log->new_values); ?>
                        <tr>
                            <td><?php echo e($log->created_at->format('d-M-Y H:i')); ?></td>
                            <td><?php echo e($log->user?->name ?? 'System'); ?></td>
                            <td><code><?php echo e($log->action); ?></code></td>
                            <td><?php echo e($log->module); ?></td>
                            <td><?php echo e($log->company?->name ?? '—'); ?></td>
                            <td><?php echo e($log->ip_address ?? '—'); ?></td>
                            <td>
                                <?php if($hasDetails): ?>
                                    <button
                                        type="button"
                                        class="btn btn-sm btn-outline-secondary"
                                        data-bs-toggle="collapse"
                                        data-bs-target="#log-<?php echo e($log->id); ?>"
                                    >
                                        Details
                                    </button>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php if($hasDetails): ?>
                            <tr class="collapse" id="log-<?php echo e($log->id); ?>">
                                <td colspan="7" class="bg-light">
                                    <?php if($log->description): ?>
                                        <p class="mb-2"><?php echo e($log->description); ?></p>
                                    <?php endif; ?>
                                    <div class="row g-3">
                                        <?php if($log->old_values): ?>
                                            <div class="col-md-6">
                                                <div class="small text-muted mb-1">Old values</div>
                                                <pre class="small mb-0"><?php echo e(json_encode($log->old_values, JSON_PRETTY_PRINT)); ?></pre>
                                            </div>
                                        <?php endif; ?>
                                        <?php if($log->new_values): ?>
                                            <div class="col-md-6">
                                                <div class="small text-muted mb-1">New values</div>
                                                <pre class="small mb-0"><?php echo e(json_encode($log->new_values, JSON_PRETTY_PRINT)); ?></pre>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center text-muted py-4">No audit log entries yet.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="mt-3">
        <?php echo e($logs->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\InvoxPakistan\resources\views/admin/audit-logs/index.blade.php ENDPATH**/ ?>