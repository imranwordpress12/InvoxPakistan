<!DOCTYPE html>
<html lang="en">
<body>
    <p>Dear <?php echo e($transaction->company->name); ?>,</p>

    <p>Thank you for your payment. We have successfully received and confirmed transaction <?php echo e($transaction->invoice_number); ?>.</p>

    <p>Amount paid: PKR <?php echo e(number_format((float) $transaction->amount, 2)); ?></p>

    <p>Regards,<br><?php echo e(config('app.name')); ?></p>
</body>
</html><?php /**PATH C:\laragon\www\InvoxPakistan\resources\views/emails/payment-thank-you.blade.php ENDPATH**/ ?>