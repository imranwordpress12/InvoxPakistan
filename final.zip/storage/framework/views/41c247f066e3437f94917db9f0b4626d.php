<!DOCTYPE html>
<html lang="en">
<body>
    <p>Hello <?php echo e($customer?->business_name ?? $transaction->company->name); ?>,</p>

    <p>
        This is a reminder that your subscription payment of
        <strong>PKR <?php echo e(number_format((float) $transaction->amount, 2)); ?></strong>
        is due on <strong><?php echo e($transaction->due_at->format('d-M-Y')); ?></strong>.
    </p>

    <p>
        <strong>Invoice:</strong> <?php echo e($transaction->invoice_number); ?><br>
        <strong>Plan:</strong> <?php echo e(ucfirst($transaction->subscription_type)); ?><br>
        <strong>Amount Due:</strong> PKR <?php echo e(number_format((float) $transaction->amount, 2)); ?><br>
        <strong>Due Date:</strong> <?php echo e($transaction->due_at->format('d-M-Y')); ?>

    </p>

    <p>Please make your payment before the due date to keep your subscription active.</p>

    <p>Thank you,<br><strong>Invox Pakistan</strong></p>
</body>
</html>
<?php /**PATH C:\laragon\www\InvoxPakistan\resources\views/emails/payment-reminder.blade.php ENDPATH**/ ?>