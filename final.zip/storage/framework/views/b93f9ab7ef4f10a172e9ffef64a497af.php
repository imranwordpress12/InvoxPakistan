<?php
    $item = $item ?? null;
?>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul class="mb-0 small">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<form
    method="POST"
    action="<?php echo e($item ? route('company.items.update', $item) : route('company.items.store')); ?>"
>
    <?php echo csrf_field(); ?>
    <?php if($item): ?>
        <?php echo method_field('PUT'); ?>
    <?php endif; ?>

    <div class="card shadow-sm mb-3">
        <div class="card-body row g-3">
            <div class="col-md-4">
                <label class="form-label">Item Code <span class="text-danger">*</span></label>
                <input
                    type="text"
                    name="item_code"
                    value="<?php echo e(old('item_code', $item?->item_code)); ?>"
                    class="form-control <?php $__errorArgs = ['item_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    required
                >
                <?php $__errorArgs = ['item_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-4">
                <label class="form-label">Item Name <span class="text-danger">*</span></label>
                <input
                    type="text"
                    name="item_name"
                    value="<?php echo e(old('item_name', $item?->item_name)); ?>"
                    class="form-control <?php $__errorArgs = ['item_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    required
                >
                <?php $__errorArgs = ['item_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-4">
                <label class="form-label">Item Type <span class="text-danger">*</span></label>
                <select name="item_type" class="form-select <?php $__errorArgs = ['item_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                    <option value="goods" <?php if(old('item_type', $item?->item_type ?? 'goods') === 'goods'): echo 'selected'; endif; ?>>Goods</option>
                    <option value="service" <?php if(old('item_type', $item?->item_type) === 'service'): echo 'selected'; endif; ?>>Service</option>
                </select>
                <?php $__errorArgs = ['item_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-3">
                <label class="form-label">Sale Type</label>
                <select name="sale_type" id="item-sale_type" class="form-select <?php $__errorArgs = ['sale_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <option value="">Select Sale Type</option>
                    <?php $__currentLoopData = $saleTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $saleType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($saleType); ?>" <?php if(old('sale_type', $item?->sale_type) === $saleType): echo 'selected'; endif; ?>><?php echo e($saleType); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <div class="form-text small" id="item-sale_type-status"></div>
                <?php $__errorArgs = ['sale_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-3">
                <label class="form-label">HS Code</label>
                <div class="position-relative">
                    <input
                        type="text"
                        name="hs_code"
                        id="item-hs_code"
                        value="<?php echo e(old('hs_code', $item?->hs_code)); ?>"
                        class="form-control <?php $__errorArgs = ['hs_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        placeholder="Type to search HS Code..."
                        autocomplete="off"
                    >
                    <div id="item-hs_code-suggestions" class="list-group position-absolute w-100 shadow-sm" style="z-index: 1000; max-height: 260px; overflow-y: auto; display: none;"></div>
                </div>
                <div class="form-text small" id="item-hs_code-description"></div>
                <div class="form-text small" id="item-hs_code-status"></div>
                <?php $__errorArgs = ['hs_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-3">
                <label class="form-label">Rate (%)</label>
                <select name="rate" id="item-rate" class="form-select <?php $__errorArgs = ['rate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <option value="">Select Rate (%)</option>
                    <?php $__currentLoopData = $taxRates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $taxRate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($taxRate->rate); ?>" <?php if(old('rate', $item?->rate) == $taxRate->rate): echo 'selected'; endif; ?>>
                            <?php echo e(number_format($taxRate->rate, 2)); ?>%
                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <div class="form-text small" id="item-rate-status"></div>
                <?php $__errorArgs = ['rate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-3">
                <label class="form-label">UoM</label>
                <select name="uom" id="item-uom" class="form-select <?php $__errorArgs = ['uom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" disabled>
                    <option value="">Select HS Code first</option>
                </select>
                <div class="form-text small" id="item-uom-status"></div>
                <?php $__errorArgs = ['uom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-3">
                <label class="form-label">Purchase Price</label>
                <input
                    type="number" step="0.01" min="0"
                    name="purchase_price"
                    value="<?php echo e(old('purchase_price', $item?->purchase_price)); ?>"
                    class="form-control <?php $__errorArgs = ['purchase_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                >
                <?php $__errorArgs = ['purchase_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-3">
                <label class="form-label">Sale Price</label>
                <input
                    type="number" step="0.01" min="0"
                    name="sale_price"
                    value="<?php echo e(old('sale_price', $item?->sale_price)); ?>"
                    class="form-control <?php $__errorArgs = ['sale_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                >
                <?php $__errorArgs = ['sale_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-3">
                <label class="form-label">Stock Quantity</label>
                <input
                    type="number" step="1" min="0"
                    name="stock_quantity"
                    value="<?php echo e(old('stock_quantity', $item?->stock_quantity ?? 0)); ?>"
                    class="form-control <?php $__errorArgs = ['stock_quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                >
                <?php $__errorArgs = ['stock_quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-3">
                <label class="form-label">Reorder Level</label>
                <input
                    type="number" step="1" min="0"
                    name="reorder_level"
                    value="<?php echo e(old('reorder_level', $item?->reorder_level ?? 0)); ?>"
                    class="form-control <?php $__errorArgs = ['reorder_level'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                >
                <?php $__errorArgs = ['reorder_level'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-9">
                <label class="form-label">Description</label>
                <textarea
                    name="description"
                    rows="2"
                    class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                ><?php echo e(old('description', $item?->description)); ?></textarea>
                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-md-3">
                <label class="form-label">Status <span class="text-danger">*</span></label>
                <select name="status" class="form-select <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                    <option value="active" <?php if(old('status', $item?->status ?? 'active') === 'active'): echo 'selected'; endif; ?>>Active</option>
                    <option value="inactive" <?php if(old('status', $item?->status) === 'inactive'): echo 'selected'; endif; ?>>Inactive</option>
                </select>
                <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
    </div>

    <div class="d-flex gap-2">
        <button type="submit" class="btn btn-primary"><?php echo e($item ? 'Update Item' : 'Save Item'); ?></button>
        <a href="<?php echo e(route('company.items.index')); ?>" class="btn btn-outline-secondary">Cancel</a>
    </div>
</form>

<?php $__env->startPush('scripts'); ?>
<script>
(function () {
    const $ = (id) => document.getElementById(id);
    const saleType = $('item-sale_type');
    const hsCode = $('item-hs_code');
    const suggestions = $('item-hs_code-suggestions');
    const rate = $('item-rate');
    const uom = $('item-uom');
    const staticSaleTypes = saleType.innerHTML;
    const staticRates = rate.innerHTML;
    const staticUoms = <?php echo json_encode($unitsOfMeasure, 15, 512) ?>;
    const staticHsCodes = <?php echo json_encode($hsCodes->map(fn ($h) => ['code' => $h->code, 'description' => $h->description]), 512) ?>;
    const oldRate = rate.value;
    const oldUom = <?php echo json_encode(old('uom', $item?->uom), 512) ?>;
    const referenceUrls = {
        transactionTypes: <?php echo json_encode(route('company.invoices.reference.transaction-types'), 15, 512) ?>,
        itemCodes: <?php echo json_encode(route('company.invoices.reference.item-codes'), 15, 512) ?>,
        hsUom: <?php echo json_encode(route('company.invoices.reference.hs-uom'), 15, 512) ?>,
        rates: <?php echo json_encode(route('company.invoices.reference.rates'), 15, 512) ?>,
    };
    const referenceDate = <?php echo json_encode(now()->toDateString(), 15, 512) ?>;
    let hsCodes = [];
    let selectedHsCode = hsCode.value || null;
    let uomSequence = 0;
    let rateSequence = 0;

    function escapeHtml(value) {
        const div = document.createElement('div');
        div.textContent = value ?? '';
        return div.innerHTML;
    }

    function status(id, message, cssClass) {
        const element = $(id);
        element.textContent = message || '';
        element.className = 'form-text small' + (cssClass ? ' ' + cssClass : '');
    }

    function retry(id, callback) {
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'btn btn-link btn-sm p-0 align-baseline';
        button.textContent = 'Retry';
        button.addEventListener('click', callback);
        $(id).append(' ', button);
    }

    function fetchReference(url, params) {
        const query = params ? '?' + new URLSearchParams(params).toString() : '';
        return fetch(url + query, { headers: { Accept: 'application/json' } })
            .then((response) => response.json().catch(() => ({})).then((body) => ({ ok: response.ok, body })));
    }

    function loadSaleTypes() {
        status('item-sale_type-status', 'Loading Sale Types from FBR...');
        return fetchReference(referenceUrls.transactionTypes).then(({ ok, body }) => {
            const rows = ok && Array.isArray(body) ? body.filter((row) => row.transactioN_DESC) : [];
            if (!rows.length) {
                saleType.innerHTML = staticSaleTypes;
                status('item-sale_type-status', (body.message || 'Unable to load Sale Types from FBR.') + ' Showing the offline list instead.', 'text-warning');
                retry('item-sale_type-status', loadSaleTypes);
                return;
            }
            saleType.innerHTML = '<option value="">Select Sale Type</option>' + rows.map((row) => `<option value="${escapeHtml(row.transactioN_DESC)}">${escapeHtml(row.transactioN_DESC)}</option>`).join('');
            status('item-sale_type-status', `${rows.length} Sale Types loaded live from FBR.`, 'text-success');
        }).catch(() => {
            saleType.innerHTML = staticSaleTypes;
            status('item-sale_type-status', 'Unable to reach FBR. Showing the offline Sale Type list instead.', 'text-warning');
            retry('item-sale_type-status', loadSaleTypes);
        });
    }

    function renderSuggestions(query) {
        const needle = query.trim().toLowerCase();
        if (!needle) {
            suggestions.style.display = 'none';
            suggestions.innerHTML = '';
            return;
        }
        const matches = hsCodes.filter((row) => row.code.toLowerCase().includes(needle) || (row.description || '').toLowerCase().includes(needle)).slice(0, 50);
        suggestions.innerHTML = matches.length
            ? matches.map((row, index) => `<button type="button" class="list-group-item list-group-item-action small" data-index="${index}"><strong>${escapeHtml(row.code)}</strong> &mdash; ${escapeHtml((row.description || '').slice(0, 90))}</button>`).join('')
            : '<div class="list-group-item small text-muted">No matching HS Code.</div>';
        suggestions.style.display = '';
        matches.forEach((row, index) => suggestions.querySelector(`[data-index="${index}"]`).addEventListener('click', () => selectHsCode(row.code, row.description)));
    }

    function selectHsCode(code, description) {
        selectedHsCode = code;
        hsCode.value = code;
        $('item-hs_code-description').textContent = description || '';
        suggestions.style.display = 'none';
        loadUom(code);
    }

    function loadHsCodes() {
        status('item-hs_code-status', 'Loading HS Codes from FBR...');
        return fetchReference(referenceUrls.itemCodes).then(({ ok, body }) => {
            hsCodes = ok && Array.isArray(body) ? body.map((row) => ({ code: row.hS_CODE, description: row.description })).filter((row) => row.code) : staticHsCodes;
            status('item-hs_code-status', hsCodes === staticHsCodes ? 'Unable to load HS Codes from FBR. Showing the offline list instead.' : `${hsCodes.length} HS Codes loaded live from FBR.`, hsCodes === staticHsCodes ? 'text-warning' : 'text-success');
            if (hsCodes === staticHsCodes) retry('item-hs_code-status', loadHsCodes);
            const known = hsCodes.find((row) => row.code === hsCode.value);
            if (known) {
                selectedHsCode = known.code;
                $('item-hs_code-description').textContent = known.description || '';
                loadUom(known.code);
            }
        }).catch(() => {
            hsCodes = staticHsCodes;
            status('item-hs_code-status', 'Unable to reach FBR. Showing the offline HS Code list instead.', 'text-warning');
            retry('item-hs_code-status', loadHsCodes);
        });
    }

    function loadUom(code) {
        const sequence = ++uomSequence;
        if (!code) {
            uom.innerHTML = '<option value="">Select HS Code first</option>';
            uom.disabled = true;
            return;
        }
        uom.disabled = true;
        uom.innerHTML = '<option value="">Loading...</option>';
        status('item-uom-status', 'Loading UOM from FBR...');
        fetchReference(referenceUrls.hsUom, { hs_code: code }).then(({ ok, body }) => {
            if (sequence !== uomSequence) return;
            const options = ok && Array.isArray(body) ? body.map((row) => row.description).filter(Boolean) : [];
            if (!options.length) {
                uom.innerHTML = '<option value="">Select UoM</option>' + staticUoms.map((value) => `<option value="${escapeHtml(value)}">${escapeHtml(value)}</option>`).join('');
                uom.disabled = false;
                uom.value = oldUom || '';
                status('item-uom-status', (body.message || 'Unable to load UOM from FBR.') + ' Showing the offline list instead.', 'text-warning');
                retry('item-uom-status', () => loadUom(code));
                return;
            }
            uom.innerHTML = '<option value="">Select UoM</option>' + options.map((value) => `<option value="${escapeHtml(value)}">${escapeHtml(value)}</option>`).join('');
            uom.disabled = false;
            if (options.includes(oldUom)) uom.value = oldUom;
            status('item-uom-status', 'UOM loaded live from FBR for this HS Code.', 'text-success');
        }).catch(() => {
            if (sequence !== uomSequence) return;
            uom.innerHTML = '<option value="">Select UoM</option>' + staticUoms.map((value) => `<option value="${escapeHtml(value)}">${escapeHtml(value)}</option>`).join('');
            uom.disabled = false;
            uom.value = oldUom || '';
            status('item-uom-status', 'Unable to reach FBR. Showing the offline UOM list instead.', 'text-warning');
            retry('item-uom-status', () => loadUom(code));
        });
    }

    function loadRate() {
        const sequence = ++rateSequence;
        const value = saleType.value;
        if (!value) {
            rate.innerHTML = staticRates;
            return;
        }
        rate.innerHTML = '<option value="">Loading...</option>';
        status('item-rate-status', 'Checking FBR for a live Rate list...');
        fetchReference(referenceUrls.rates, { sale_type: value, date: referenceDate }).then(({ ok, body }) => {
            if (sequence !== rateSequence) return;
            if (!ok) {
                rate.innerHTML = staticRates;
                rate.value = oldRate;
                status('item-rate-status', ((body && body.message) ? body.message + ' Showing the offline list instead.' : 'Unable to reach FBR. Showing the offline Rate list instead.'), 'text-warning');
                retry('item-rate-status', loadRate);
                return;
            }
            if (body.resolvable === false) {
                rate.innerHTML = staticRates;
                rate.value = oldRate;
                status('item-rate-status', (body && body.message) || 'Live FBR Rate lookup unavailable; showing the offline list instead.', 'text-muted');
                return;
            }
            const rates = body.rates || [];
            if (!rates.length) {
                rate.innerHTML = staticRates;
                rate.value = oldRate;
                status('item-rate-status', 'FBR returned no Rates for this Sale Type; showing the offline list instead.', 'text-warning');
                return;
            }
            rate.innerHTML = '<option value="">Select Rate (%)</option>' + rates.map((row) => `<option value="${Number(row.ratE_VALUE)}">${escapeHtml(row.ratE_DESC)}</option>`).join('');
            rate.value = oldRate;
            status('item-rate-status', 'Live Rate list loaded from FBR.', 'text-success');
        }).catch(() => {
            if (sequence !== rateSequence) return;
            rate.innerHTML = staticRates;
            rate.value = oldRate;
            status('item-rate-status', 'Unable to reach FBR. Showing the offline Rate list instead.', 'text-warning');
            retry('item-rate-status', loadRate);
        });
    }

    saleType.addEventListener('change', loadRate);
    hsCode.addEventListener('input', function () {
        selectedHsCode = null;
        loadUom('');
        renderSuggestions(this.value);
    });
    hsCode.addEventListener('focus', () => renderSuggestions(hsCode.value));
    document.addEventListener('click', (event) => {
        if (!suggestions.contains(event.target) && event.target !== hsCode) suggestions.style.display = 'none';
    });

    Promise.all([loadSaleTypes(), loadHsCodes()]).then(loadRate);
})();
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\laragon\www\InvoxPakistan\resources\views/company/items/_form.blade.php ENDPATH**/ ?>